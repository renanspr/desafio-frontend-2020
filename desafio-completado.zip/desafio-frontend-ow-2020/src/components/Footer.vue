<template>
  <div id="footer">
    <img src="../assets/resourcesmin/icons/MktPlace-footer.png" alt="" />
  </div>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style lang="scss" scoped>
@import "../../public/sass/index.scss";
</style>
